# 🛒 Harvest & Co. — Full-Stack Grocery Store

A complete grocery e-commerce web app built with:

- **Frontend:** HTML5, CSS3, Bootstrap 5, vanilla JavaScript (no framework/build step)
- **Backend:** Node.js, Express.js (REST API)
- **Database:** MySQL
- **Auth:** JWT (JSON Web Tokens) + bcrypt password hashing

## ✨ Features

**Customer**
- Browse products by category, search, sort, and paginate
- Product detail pages with related products
- Persistent server-side shopping cart
- Checkout with shipping form + mock payment (Cash on Delivery / Card / UPI)
- Order history and order detail/tracking pages
- Register / Login with JWT auth

**Admin**
- Dashboard with revenue, order count, product count, customer count, low-stock alerts, recent orders
- Full product CRUD (create, edit, delete, feature, mark organic, discount)
- Order management — view all orders and update their status

## 📁 Project Structure

```
grocery-store/
├── backend/
│   ├── config/db.js              # MySQL connection pool
│   ├── controllers/              # Route handler logic
│   ├── middleware/auth.js        # JWT verification + admin guard
│   ├── routes/                   # Express routers
│   ├── database/
│   │   ├── schema.sql            # Table definitions
│   │   ├── seed.sql              # Sample categories & products
│   │   └── createAdmin.js        # Script to create the admin user
│   ├── server.js                 # App entry point
│   ├── package.json
│   └── .env.example
└── frontend/
    ├── index.html, products.html, product-detail.html
    ├── cart.html, checkout.html, order-success.html
    ├── login.html, register.html, orders.html, order-detail.html
    ├── admin/dashboard.html, admin/products.html, admin/orders.html
    ├── css/style.css
    └── js/  (api.js, main.js, auth.js, products.js, cart.js, checkout.js, ...)
```

## 🚀 Setup & Run

### 1. Prerequisites
- [Node.js](https://nodejs.org) v18+ installed
- [MySQL](https://dev.mysql.com/downloads/) server installed and running

### 2. Set up the database

```bash
mysql -u root -p < backend/database/schema.sql
mysql -u root -p < backend/database/seed.sql
```

This creates the `grocery_store` database with all tables, plus 8 categories and 33 sample products.

### 3. Configure & install the backend

```bash
cd backend
cp .env.example .env
```

Edit `.env` and set your MySQL password and a long random `JWT_SECRET`.

```bash
npm install
node database/createAdmin.js
```

The last command creates the admin login:
- **Email:** `admin@grocerystore.com`
- **Password:** `Admin@123`

(You can pass custom values: `node database/createAdmin.js you@example.com MyPassword1`)

### 4. Start the backend API

```bash
npm start
```

You should see:
```
✅ MySQL connected successfully
🛒 Grocery Store API running on http://localhost:5000
```

Visit `http://localhost:5000/api/health` to confirm it's running.

### 5. Run the frontend

The frontend is plain static HTML/CSS/JS — no build step needed. From the `frontend/` folder, serve it with any static server, for example:

```bash
cd frontend
npx serve .
# or: python3 -m http.server 5500
```

Then open the printed URL (e.g. `http://localhost:3000` or `http://localhost:5500`) in your browser.

> ⚠️ The frontend calls the API at `http://localhost:5000/api` (see the `API_BASE_URL` constant at the top of `frontend/js/api.js`). Change it there if your backend runs elsewhere.

### 6. Try it out
- Register a new customer account, browse products, add to cart, and check out.
- Log in as `admin@grocerystore.com` and open `admin/dashboard.html` to manage products and orders.

## 🔌 REST API Reference

| Method | Endpoint | Auth | Description |
|---|---|---|---|
| POST | `/api/auth/register` | – | Create a customer account |
| POST | `/api/auth/login` | – | Log in, returns JWT |
| GET | `/api/auth/me` | ✅ | Current user profile |
| GET | `/api/products` | – | List products (search, category, sort, page, limit, featured) |
| GET | `/api/products/:id` | – | Product detail |
| POST | `/api/products` | 🔒 Admin | Create product |
| PUT | `/api/products/:id` | 🔒 Admin | Update product |
| DELETE | `/api/products/:id` | 🔒 Admin | Delete product |
| GET | `/api/categories` | – | List categories |
| POST | `/api/categories` | 🔒 Admin | Create category |
| GET | `/api/cart` | ✅ | Get current user's cart |
| POST | `/api/cart` | ✅ | Add item to cart |
| PUT | `/api/cart/:itemId` | ✅ | Update quantity |
| DELETE | `/api/cart/:itemId` | ✅ | Remove item |
| DELETE | `/api/cart` | ✅ | Clear cart |
| POST | `/api/orders` | ✅ | Checkout — creates order, runs mock payment |
| GET | `/api/orders` | ✅ | My order history |
| GET | `/api/orders/:id` | ✅ | Order detail |
| GET | `/api/admin/stats` | 🔒 Admin | Dashboard summary |
| GET | `/api/admin/orders` | 🔒 Admin | All orders |
| PUT | `/api/admin/orders/:id/status` | 🔒 Admin | Update order status |

✅ = requires `Authorization: Bearer <token>` header. 🔒 Admin = requires an admin-role JWT.

## 💳 About the "Payment Gateway"

Card/UPI payment is **simulated** on the server (`processMockPayment` in `orders.controller.js`) — it validates card shape and always marks the order as paid, since no real payment provider is wired in. Swap this function out for a real Stripe/Razorpay/PayPal integration when you're ready to go live; the rest of the checkout flow (cart → order → stock deduction → order history) is fully functional and production-shaped.

## 🎨 Design

The frontend uses a "farm-stand" visual identity: deep forest green + turmeric gold + a monospace price-tag font (IBM Plex Mono) paired with a serif display font (Fraunces), built entirely with Bootstrap 5 utilities and a small custom stylesheet (`css/style.css`) — no React or build tooling required.
