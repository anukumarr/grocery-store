const CO_DELIVERY_FEE = 4.99;
const CO_FREE_DELIVERY_THRESHOLD = 30;

async function loadCheckoutSummary() {
  const guard = document.getElementById('hc-checkout-guard');
  const itemsWrap = document.getElementById('hc-checkout-items');

  if (!Api.isLoggedIn()) {
    window.location.href = 'login.html?next=checkout.html';
    return;
  }

  try {
    const cart = await Api.get('/cart');
    if (cart.items.length === 0) {
      guard.innerHTML = `<div class="alert alert-warning">Your cart is empty. <a href="products.html">Go shopping</a> before checking out.</div>`;
      document.getElementById('hc-place-order-btn').disabled = true;
      return;
    }

    itemsWrap.innerHTML = cart.items.map(item => `
      <div class="d-flex justify-content-between align-items-center small mb-2">
        <span>${item.name} <span class="text-muted">× ${item.quantity}</span></span>
        <span class="fw-semibold">${hcFormatMoney(item.final_price * item.quantity)}</span>
      </div>
    `).join('');

    const subtotal = cart.subtotal;
    const delivery = subtotal >= CO_FREE_DELIVERY_THRESHOLD ? 0 : CO_DELIVERY_FEE;
    const total = subtotal + delivery;

    document.getElementById('hc-co-subtotal').textContent = hcFormatMoney(subtotal);
    document.getElementById('hc-co-delivery').textContent = delivery === 0 ? 'FREE' : hcFormatMoney(delivery);
    document.getElementById('hc-co-total').textContent = hcFormatMoney(total);
  } catch (err) {
    guard.innerHTML = `<div class="alert alert-danger">${err.message}</div>`;
  }
}

document.addEventListener('DOMContentLoaded', () => {
  loadCheckoutSummary();

  document.querySelectorAll('input[name="payment_method"]').forEach(radio => {
    radio.addEventListener('change', () => {
      document.getElementById('hc-card-fields').classList.toggle('d-none', radio.value !== 'card');
    });
  });

  document.getElementById('hc-checkout-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const errorBox = document.getElementById('hc-checkout-error');
    errorBox.classList.add('d-none');

    const submitBtn = document.getElementById('hc-place-order-btn');
    submitBtn.disabled = true;
    submitBtn.textContent = 'Placing order...';

    const payload = {
      shipping_name: document.getElementById('ship-name').value.trim(),
      shipping_phone: document.getElementById('ship-phone').value.trim(),
      shipping_address: document.getElementById('ship-address').value.trim(),
      shipping_city: document.getElementById('ship-city').value.trim(),
      shipping_zip: document.getElementById('ship-zip').value.trim(),
      payment_method: document.querySelector('input[name="payment_method"]:checked').value,
      card_number: document.getElementById('card-number').value,
      card_expiry: document.getElementById('card-expiry').value,
      card_cvv: document.getElementById('card-cvv').value
    };

    try {
      const result = await Api.post('/orders', payload);
      sessionStorage.setItem('hc_last_order_id', result.order_id);
      window.location.href = 'order-success.html';
    } catch (err) {
      errorBox.textContent = err.message;
      errorBox.classList.remove('d-none');
      submitBtn.disabled = false;
      submitBtn.textContent = 'Place Order';
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  });
});
