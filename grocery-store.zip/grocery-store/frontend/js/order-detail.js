function odStatusBadge(status) {
  return `<span class="hc-status hc-status-${status}">${status}</span>`;
}

async function loadOrderDetail() {
  const wrap = document.getElementById('hc-order-detail');
  if (!hcRequireLogin('Please sign in to view this order')) return;

  const id = new URLSearchParams(window.location.search).get('id');
  if (!id) {
    wrap.innerHTML = `<div class="alert alert-warning">No order specified.</div>`;
    return;
  }

  try {
    const order = await Api.get(`/orders/${id}`);
    const itemsTotal = order.items.reduce((sum, i) => sum + i.price * i.quantity, 0);
    const delivery = order.total_amount - itemsTotal;

    wrap.innerHTML = `
      <div class="d-flex justify-content-between align-items-start flex-wrap gap-2 mb-4">
        <div>
          <h1 class="h3 mb-1">Order #${order.id}</h1>
          <p class="text-muted small mb-0">Placed on ${new Date(order.created_at).toLocaleString()}</p>
        </div>
        ${odStatusBadge(order.status)}
      </div>

      <div class="row g-4">
        <div class="col-lg-8">
          <div class="bg-white border rounded-3 p-4" style="border-color: var(--color-border) !important;">
            <h2 class="h6 text-uppercase text-muted mb-3">Items</h2>
            ${order.items.map(i => `
              <div class="d-flex justify-content-between align-items-center py-2 border-bottom">
                <div>
                  <div class="fw-semibold">${i.product_name}</div>
                  <div class="small text-muted">${hcFormatMoney(i.price)} × ${i.quantity}</div>
                </div>
                <div class="hc-price-tag">${hcFormatMoney(i.price * i.quantity)}</div>
              </div>
            `).join('')}
          </div>
        </div>
        <div class="col-lg-4">
          <div class="hc-summary-card mb-3">
            <h2 class="h6 text-uppercase text-muted mb-3">Payment Summary</h2>
            <div class="d-flex justify-content-between small mb-2"><span class="text-muted">Items Total</span><span>${hcFormatMoney(itemsTotal)}</span></div>
            <div class="d-flex justify-content-between small mb-2"><span class="text-muted">Delivery</span><span>${delivery <= 0 ? 'FREE' : hcFormatMoney(delivery)}</span></div>
            <hr>
            <div class="d-flex justify-content-between mb-2"><span class="fw-bold">Total</span><span class="hc-price-tag">${hcFormatMoney(order.total_amount)}</span></div>
            <div class="small text-muted text-uppercase mt-2">Payment: ${order.payment_method} · ${order.payment_status}</div>
          </div>
          <div class="hc-summary-card" style="position: static;">
            <h2 class="h6 text-uppercase text-muted mb-3">Shipping To</h2>
            <div class="small">
              <div class="fw-semibold">${order.shipping_name}</div>
              <div>${order.shipping_address}</div>
              <div>${order.shipping_city}, ${order.shipping_zip}</div>
              <div class="mt-1"><i class="bi bi-telephone"></i> ${order.shipping_phone}</div>
            </div>
          </div>
        </div>
      </div>`;
  } catch (err) {
    wrap.innerHTML = `<div class="alert alert-danger">${err.message}</div>`;
  }
}

document.addEventListener('DOMContentLoaded', loadOrderDetail);
