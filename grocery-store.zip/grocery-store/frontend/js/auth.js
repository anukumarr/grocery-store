document.addEventListener('DOMContentLoaded', () => {
  // Redirect already-logged-in users away from login/register pages
  if (Api.isLoggedIn() && (document.getElementById('hc-login-form') || document.getElementById('hc-register-form'))) {
    window.location.href = 'index.html';
    return;
  }

  const loginForm = document.getElementById('hc-login-form');
  if (loginForm) {
    loginForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const errorBox = document.getElementById('hc-auth-error');
      errorBox.classList.add('d-none');

      const email = document.getElementById('login-email').value.trim();
      const password = document.getElementById('login-password').value;
      const submitBtn = loginForm.querySelector('button[type="submit"]');
      submitBtn.disabled = true;
      submitBtn.textContent = 'Signing in...';

      try {
        const data = await Api.post('/auth/login', { email, password });
        Api.setToken(data.token);
        Api.setUser(data.user);

        const params = new URLSearchParams(window.location.search);
        const next = params.get('next');
        window.location.href = (next && next !== 'login.html') ? next : 'index.html';
      } catch (err) {
        errorBox.textContent = err.message;
        errorBox.classList.remove('d-none');
        submitBtn.disabled = false;
        submitBtn.textContent = 'Sign In';
      }
    });
  }

  const registerForm = document.getElementById('hc-register-form');
  if (registerForm) {
    registerForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const errorBox = document.getElementById('hc-auth-error');
      errorBox.classList.add('d-none');

      const name = document.getElementById('reg-name').value.trim();
      const email = document.getElementById('reg-email').value.trim();
      const phone = document.getElementById('reg-phone').value.trim();
      const password = document.getElementById('reg-password').value;
      const confirm = document.getElementById('reg-confirm').value;
      const submitBtn = registerForm.querySelector('button[type="submit"]');

      if (password !== confirm) {
        errorBox.textContent = 'Passwords do not match';
        errorBox.classList.remove('d-none');
        return;
      }

      submitBtn.disabled = true;
      submitBtn.textContent = 'Creating account...';

      try {
        const data = await Api.post('/auth/register', { name, email, phone, password });
        Api.setToken(data.token);
        Api.setUser(data.user);
        window.location.href = 'index.html';
      } catch (err) {
        errorBox.textContent = err.message;
        errorBox.classList.remove('d-none');
        submitBtn.disabled = false;
        submitBtn.textContent = 'Create Account';
      }
    });
  }
});
