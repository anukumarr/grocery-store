function getProductIdFromUrl() {
  return new URLSearchParams(window.location.search).get('id');
}

async function loadProductDetail() {
  const wrap = document.getElementById('hc-product-detail');
  const id = getProductIdFromUrl();
  if (!id) {
    wrap.innerHTML = `<div class="hc-empty-state"><i class="bi bi-question-circle"></i><p class="mt-3">No product specified.</p></div>`;
    return;
  }

  try {
    const p = await Api.get(`/products/${id}`);
    const finalPrice = p.price - (p.price * (p.discount_percent || 0)) / 100;
    const outOfStock = p.stock <= 0;

    wrap.innerHTML = `
      <div class="row g-5">
        <div class="col-md-6">
          <div class="hc-product-img-wrap" style="border-radius: var(--radius-lg); aspect-ratio: 1;">
            ${p.is_organic ? '<span class="hc-badge-stamp hc-badge-organic">Organic</span>' : ''}
            ${p.discount_percent > 0 ? `<span class="hc-badge-stamp hc-badge-sale" style="left:auto; right:10px;">-${p.discount_percent}%</span>` : ''}
            <img src="${p.image_url || 'https://via.placeholder.com/500'}" alt="${p.name}" style="width:100%; height:100%; object-fit:cover;">
          </div>
        </div>
        <div class="col-md-6">
          <nav aria-label="breadcrumb">
            <ol class="breadcrumb small">
              <li class="breadcrumb-item"><a href="products.html">Shop</a></li>
              <li class="breadcrumb-item"><a href="products.html?category=${p.category_id}">${p.category_name || 'Category'}</a></li>
              <li class="breadcrumb-item active">${p.name}</li>
            </ol>
          </nav>
          <h1 class="h2">${p.name}</h1>
          <p class="text-muted">${p.description || 'No description available.'}</p>
          <div class="d-flex align-items-center gap-3 mb-3">
            ${p.discount_percent > 0 ? `<span class="hc-price-strike fs-6">${hcFormatMoney(p.price)}</span>` : ''}
            <span class="hc-price-tag fs-3">${hcFormatMoney(finalPrice)}</span>
            <span class="text-muted">/ ${p.unit}</span>
          </div>
          <p class="mb-3">
            ${outOfStock
              ? '<span class="hc-status hc-status-cancelled">Out of Stock</span>'
              : p.stock <= 10
                ? `<span class="hc-status hc-status-pending">Only ${p.stock} left</span>`
                : '<span class="hc-status hc-status-delivered">In Stock</span>'}
          </p>
          <div class="d-flex align-items-center gap-3 mb-4">
            <div class="hc-qty-control">
              <button type="button" onclick="hcChangeQty(-1)">-</button>
              <input type="number" id="hc-detail-qty" value="1" min="1" max="${p.stock}">
              <button type="button" onclick="hcChangeQty(1)">+</button>
            </div>
            <button class="btn btn-hc-primary px-4" ${outOfStock ? 'disabled' : ''} onclick="hcAddDetailToCart(${p.id})">
              <i class="bi bi-basket3 me-1"></i> Add to Cart
            </button>
          </div>
          <ul class="list-unstyled small text-muted">
            <li><i class="bi bi-truck me-1"></i> Free delivery on orders over $30</li>
            <li><i class="bi bi-arrow-repeat me-1"></i> Freshness guaranteed or your money back</li>
          </ul>
        </div>
      </div>`;

    loadRelated(p.category_id, p.id);
  } catch (err) {
    wrap.innerHTML = `<div class="hc-empty-state"><i class="bi bi-exclamation-triangle"></i><p class="mt-3">${err.message}</p></div>`;
  }
}

function hcChangeQty(delta) {
  const input = document.getElementById('hc-detail-qty');
  const max = parseInt(input.max) || 999;
  let val = parseInt(input.value) + delta;
  if (val < 1) val = 1;
  if (val > max) val = max;
  input.value = val;
}

async function hcAddDetailToCart(productId) {
  if (!Api.isLoggedIn()) {
    hcShowToast('Please sign in to add items to your cart', 'info');
    setTimeout(() => window.location.href = `login.html?next=${encodeURIComponent(window.location.pathname.split('/').pop() + window.location.search)}`, 900);
    return;
  }
  const qty = parseInt(document.getElementById('hc-detail-qty').value) || 1;
  try {
    await Api.post('/cart', { product_id: productId, quantity: qty });
    hcShowToast('Added to cart');
    hcRefreshCartBadge();
  } catch (err) {
    hcShowToast(err.message, 'error');
  }
}

async function loadRelated(categoryId, excludeId) {
  const wrap = document.getElementById('hc-related');
  try {
    const data = await Api.get(`/products?category=${categoryId}&limit=4`);
    const related = data.products.filter(p => p.id != excludeId).slice(0, 4);
    wrap.innerHTML = related.length
      ? related.map(productCardHTML).join('')
      : `<div class="col-12 text-muted small">No related products found.</div>`;
  } catch (err) {
    wrap.innerHTML = '';
  }
}

document.addEventListener('DOMContentLoaded', loadProductDetail);
