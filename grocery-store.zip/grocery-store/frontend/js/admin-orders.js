let hcAllOrders = [];

const STATUS_OPTIONS = ['pending', 'processing', 'shipped', 'delivered', 'cancelled'];

async function loadAdminOrders() {
  const tbody = document.getElementById('hc-orders-table');
  try {
    hcAllOrders = await Api.get('/admin/orders');
    renderOrdersTable();
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="7" class="text-center text-danger py-4">${err.message}</td></tr>`;
  }
}

function renderOrdersTable() {
  const tbody = document.getElementById('hc-orders-table');
  const filter = document.getElementById('hc-status-filter').value;
  const filtered = filter ? hcAllOrders.filter(o => o.status === filter) : hcAllOrders;

  if (filtered.length === 0) {
    tbody.innerHTML = `<tr><td colspan="7" class="text-center text-muted py-4">No orders found.</td></tr>`;
    return;
  }

  tbody.innerHTML = filtered.map(o => `
    <tr>
      <td class="fw-semibold small">#${o.id}</td>
      <td class="small">${o.customer_name}<div class="text-muted">${o.customer_email}</div></td>
      <td class="small text-muted">${new Date(o.created_at).toLocaleDateString()}</td>
      <td class="hc-price-tag small">$${Number(o.total_amount).toFixed(2)}</td>
      <td class="small text-uppercase">${o.payment_method} <span class="text-muted">(${o.payment_status})</span></td>
      <td><span class="hc-status hc-status-${o.status}">${o.status}</span></td>
      <td>
        <select class="form-select form-select-sm" style="min-width:130px;" onchange="updateStatus(${o.id}, this.value)">
          ${STATUS_OPTIONS.map(s => `<option value="${s}" ${s === o.status ? 'selected' : ''}>${s}</option>`).join('')}
        </select>
      </td>
    </tr>
  `).join('');
}

async function updateStatus(orderId, status) {
  try {
    await Api.put(`/admin/orders/${orderId}/status`, { status });
    hcShowToast(`Order #${orderId} marked as ${status}`);
    const order = hcAllOrders.find(o => o.id === orderId);
    if (order) order.status = status;
    renderOrdersTable();
  } catch (err) {
    alert(err.message);
  }
}

document.addEventListener('DOMContentLoaded', () => {
  loadAdminOrders();
  document.getElementById('hc-status-filter').addEventListener('change', renderOrdersTable);
});
