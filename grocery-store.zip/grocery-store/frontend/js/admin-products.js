let hcAllCategories = [];
let hcProductModal;

async function loadCategoriesIntoSelect() {
  try {
    hcAllCategories = await Api.get('/categories');
    const select = document.getElementById('pf-category');
    select.innerHTML = `<option value="">— No Category —</option>` +
      hcAllCategories.map(c => `<option value="${c.id}">${c.name}</option>`).join('');
  } catch (err) {
    console.error(err);
  }
}

function categoryName(id) {
  const cat = hcAllCategories.find(c => c.id == id);
  return cat ? cat.name : '—';
}

async function loadProductsTable() {
  const tbody = document.getElementById('hc-products-table');
  try {
    const data = await Api.get('/products?limit=100');
    if (data.products.length === 0) {
      tbody.innerHTML = `<tr><td colspan="7" class="text-center text-muted py-4">No products yet. Add your first one.</td></tr>`;
      return;
    }

    tbody.innerHTML = data.products.map(p => `
      <tr>
        <td><img src="${p.image_url || 'https://via.placeholder.com/48'}" style="width:48px;height:48px;object-fit:cover;border-radius:6px;"></td>
        <td class="fw-semibold small">${p.name}</td>
        <td class="small text-muted">${p.category_name || '—'}</td>
        <td class="hc-price-tag small">$${Number(p.price).toFixed(2)}</td>
        <td class="small">
          <span class="hc-status ${p.stock === 0 ? 'hc-status-cancelled' : p.stock <= 10 ? 'hc-status-pending' : 'hc-status-delivered'}">${p.stock}</span>
        </td>
        <td class="small">
          ${p.is_featured ? '<span class="badge bg-warning text-dark me-1">Featured</span>' : ''}
          ${p.is_organic ? '<span class="badge bg-success">Organic</span>' : ''}
          ${p.discount_percent > 0 ? `<span class="badge bg-danger">-${p.discount_percent}%</span>` : ''}
        </td>
        <td class="text-end">
          <button class="btn btn-sm btn-outline-secondary me-1" onclick='openProductModal(${JSON.stringify(p)})'><i class="bi bi-pencil"></i></button>
          <button class="btn btn-sm btn-outline-danger" onclick="deleteProduct(${p.id}, '${p.name.replace(/'/g, "\\'")}')"><i class="bi bi-trash"></i></button>
        </td>
      </tr>
    `).join('');
  } catch (err) {
    tbody.innerHTML = `<tr><td colspan="7" class="text-center text-danger py-4">${err.message}</td></tr>`;
  }
}

function openProductModal(product = null) {
  document.getElementById('pf-error').classList.add('d-none');
  const form = document.getElementById('hc-product-form');
  form.reset();

  if (product) {
    document.getElementById('productModalTitle').textContent = 'Edit Product';
    document.getElementById('pf-id').value = product.id;
    document.getElementById('pf-name').value = product.name;
    document.getElementById('pf-description').value = product.description || '';
    document.getElementById('pf-price').value = product.price;
    document.getElementById('pf-unit').value = product.unit || '';
    document.getElementById('pf-stock').value = product.stock;
    document.getElementById('pf-discount').value = product.discount_percent || 0;
    document.getElementById('pf-image').value = product.image_url || '';
    document.getElementById('pf-category').value = product.category_id || '';
    document.getElementById('pf-featured').checked = !!product.is_featured;
    document.getElementById('pf-organic').checked = !!product.is_organic;
  } else {
    document.getElementById('productModalTitle').textContent = 'Add Product';
    document.getElementById('pf-id').value = '';
  }
}

async function deleteProduct(id, name) {
  if (!confirm(`Delete "${name}"? This cannot be undone.`)) return;
  try {
    await Api.del(`/products/${id}`);
    hcShowToast('Product deleted');
    loadProductsTable();
  } catch (err) {
    alert(err.message);
  }
}

document.addEventListener('DOMContentLoaded', () => {
  loadCategoriesIntoSelect();
  loadProductsTable();

  document.getElementById('hc-product-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const errorBox = document.getElementById('pf-error');
    errorBox.classList.add('d-none');

    const id = document.getElementById('pf-id').value;
    const payload = {
      name: document.getElementById('pf-name').value.trim(),
      description: document.getElementById('pf-description').value.trim(),
      price: parseFloat(document.getElementById('pf-price').value),
      unit: document.getElementById('pf-unit').value.trim() || 'each',
      stock: parseInt(document.getElementById('pf-stock').value),
      discount_percent: parseFloat(document.getElementById('pf-discount').value) || 0,
      image_url: document.getElementById('pf-image').value.trim(),
      category_id: document.getElementById('pf-category').value || null,
      is_featured: document.getElementById('pf-featured').checked,
      is_organic: document.getElementById('pf-organic').checked
    };

    const submitBtn = document.getElementById('pf-submit-btn');
    submitBtn.disabled = true;

    try {
      if (id) {
        await Api.put(`/products/${id}`, payload);
        hcShowToast('Product updated');
      } else {
        await Api.post('/products', payload);
        hcShowToast('Product created');
      }
      bootstrap.Modal.getInstance(document.getElementById('productModal')).hide();
      loadProductsTable();
    } catch (err) {
      errorBox.textContent = err.message;
      errorBox.classList.remove('d-none');
    } finally {
      submitBtn.disabled = false;
    }
  });
});
