const hcState = {
  page: 1,
  limit: 12,
  category: null,
  search: '',
  sort: '',
  featured: false
};

function hcReadParamsFromUrl() {
  const params = new URLSearchParams(window.location.search);
  hcState.search = params.get('search') || '';
  hcState.category = params.get('category') || null;
  hcState.featured = params.get('featured') === 'true';
  hcState.page = parseInt(params.get('page')) || 1;
}

async function hcLoadCategoryFilters() {
  const wrap = document.getElementById('hc-cat-filters');
  try {
    const categories = await Api.get('/categories');
    let html = `<a href="#" class="hc-cat-link ${!hcState.category ? 'fw-bold text-dark' : 'text-muted'}" data-id="">All Categories</a>`;
    html += categories.map(c => `
      <a href="#" class="hc-cat-link ${hcState.category == c.id ? 'fw-bold text-dark' : 'text-muted'}" data-id="${c.id}">${c.name}</a>
    `).join('');
    wrap.innerHTML = html;

    wrap.querySelectorAll('.hc-cat-link').forEach(link => {
      link.addEventListener('click', (e) => {
        e.preventDefault();
        hcState.category = link.dataset.id || null;
        hcState.page = 1;
        hcLoadProducts();
        hcLoadCategoryFilters();
      });
    });
  } catch (err) {
    wrap.innerHTML = '<span class="text-muted">Could not load categories</span>';
  }
}

async function hcLoadProducts() {
  const grid = document.getElementById('hc-product-grid');
  const countEl = document.getElementById('hc-result-count');
  grid.innerHTML = `<div class="col-12 text-center text-muted py-5"><div class="spinner-border" role="status"></div></div>`;

  const qs = new URLSearchParams();
  qs.set('page', hcState.page);
  qs.set('limit', hcState.limit);
  if (hcState.category) qs.set('category', hcState.category);
  if (hcState.search) qs.set('search', hcState.search);
  if (hcState.sort) qs.set('sort', hcState.sort);
  if (hcState.featured) qs.set('featured', 'true');

  try {
    const data = await Api.get(`/products?${qs.toString()}`);
    if (data.products.length === 0) {
      grid.innerHTML = `
        <div class="col-12 hc-empty-state">
          <i class="bi bi-basket"></i>
          <p class="mt-3">No products matched your search. Try a different keyword or category.</p>
        </div>`;
      countEl.textContent = '';
    } else {
      grid.innerHTML = data.products.map(productCardHTML).join('');
      countEl.textContent = `Showing ${data.products.length} of ${data.total} products`;
    }
    hcRenderPagination(data.totalPages, data.page);
  } catch (err) {
    grid.innerHTML = `<div class="col-12 text-muted small">Could not load products — is the backend running on http://localhost:5000?</div>`;
  }
}

function hcRenderPagination(totalPages, currentPage) {
  const pag = document.getElementById('hc-pagination');
  pag.innerHTML = '';
  if (totalPages <= 1) return;

  for (let i = 1; i <= totalPages; i++) {
    const li = document.createElement('li');
    li.className = `page-item ${i === currentPage ? 'active' : ''}`;
    li.innerHTML = `<a class="page-link" href="#">${i}</a>`;
    li.querySelector('a').addEventListener('click', (e) => {
      e.preventDefault();
      hcState.page = i;
      hcLoadProducts();
      window.scrollTo({ top: 0, behavior: 'smooth' });
    });
    pag.appendChild(li);
  }
}

document.addEventListener('DOMContentLoaded', () => {
  hcReadParamsFromUrl();
  document.querySelector('input[name="q"]').value = hcState.search;

  hcLoadCategoryFilters();
  hcLoadProducts();

  document.getElementById('hc-sort').addEventListener('change', (e) => {
    hcState.sort = e.target.value;
    hcState.page = 1;
    hcLoadProducts();
  });

  document.getElementById('hc-clear-filters').addEventListener('click', () => {
    hcState.category = null;
    hcState.search = '';
    hcState.sort = '';
    hcState.featured = false;
    hcState.page = 1;
    document.getElementById('hc-sort').value = '';
    document.querySelector('input[name="q"]').value = '';
    history.replaceState(null, '', 'products.html');
    hcLoadProducts();
    hcLoadCategoryFilters();
  });
});
