function statusBadge(status) {
  return `<span class="hc-status hc-status-${status}">${status}</span>`;
}

async function loadOrders() {
  const wrap = document.getElementById('hc-orders-list');

  if (!hcRequireLogin('Please sign in to view your orders')) return;

  try {
    const orders = await Api.get('/orders');
    if (orders.length === 0) {
      wrap.innerHTML = `
        <div class="hc-empty-state">
          <i class="bi bi-receipt"></i>
          <p class="mt-3">You haven't placed any orders yet.</p>
          <a href="products.html" class="btn btn-hc-primary mt-2">Start Shopping</a>
        </div>`;
      return;
    }

    wrap.innerHTML = `
      <div class="table-responsive">
        <table class="table align-middle bg-white">
          <thead>
            <tr class="text-muted small text-uppercase">
              <th>Order</th>
              <th>Date</th>
              <th>Total</th>
              <th>Payment</th>
              <th>Status</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            ${orders.map(o => `
              <tr>
                <td class="fw-semibold">#${o.id}</td>
                <td class="small text-muted">${new Date(o.created_at).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' })}</td>
                <td class="hc-price-tag">${hcFormatMoney(o.total_amount)}</td>
                <td class="small text-uppercase">${o.payment_method}</td>
                <td>${statusBadge(o.status)}</td>
                <td><a href="order-detail.html?id=${o.id}" class="btn btn-sm btn-hc-outline">View</a></td>
              </tr>
            `).join('')}
          </tbody>
        </table>
      </div>`;
  } catch (err) {
    wrap.innerHTML = `<div class="text-muted small">${err.message}</div>`;
  }
}

document.addEventListener('DOMContentLoaded', loadOrders);
