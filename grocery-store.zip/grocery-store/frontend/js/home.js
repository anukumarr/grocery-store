function productCardHTML(p) {
  const finalPrice = p.price - (p.price * (p.discount_percent || 0)) / 100;
  const outOfStock = p.stock <= 0;
  let badge = '';
  if (outOfStock) badge = `<span class="hc-badge-stamp hc-badge-out">Sold Out</span>`;
  else if (p.discount_percent > 0) badge = `<span class="hc-badge-stamp hc-badge-sale">-${p.discount_percent}%</span>`;
  else if (p.is_organic) badge = `<span class="hc-badge-stamp hc-badge-organic">Organic</span>`;

  return `
  <div class="col">
    <div class="hc-product-card">
      <a href="product-detail.html?id=${p.id}" class="text-decoration-none">
        <div class="hc-product-img-wrap">
          ${badge}
          <img src="${p.image_url || 'https://via.placeholder.com/400x300?text=Product'}" alt="${p.name}" loading="lazy">
        </div>
      </a>
      <div class="hc-product-body">
        <a href="product-detail.html?id=${p.id}" class="hc-product-name">${p.name}</a>
        <div class="hc-product-unit mb-2">per ${p.unit}</div>
        <div class="d-flex justify-content-between align-items-center">
          <div>
            ${p.discount_percent > 0 ? `<span class="hc-price-strike">${hcFormatMoney(p.price)}</span>` : ''}
            <span class="hc-price-tag">${hcFormatMoney(finalPrice)}</span>
          </div>
          <button class="btn btn-hc-primary btn-sm" ${outOfStock ? 'disabled' : ''} onclick="hcQuickAdd(${p.id})">
            <i class="bi bi-plus-lg"></i>
          </button>
        </div>
      </div>
    </div>
  </div>`;
}

async function hcQuickAdd(productId) {
  if (!Api.isLoggedIn()) {
    hcShowToast('Please sign in to add items to your cart', 'info');
    setTimeout(() => window.location.href = `login.html?next=${encodeURIComponent(window.location.pathname.split('/').pop())}`, 900);
    return;
  }
  try {
    await Api.post('/cart', { product_id: productId, quantity: 1 });
    hcShowToast('Added to cart');
    hcRefreshCartBadge();
  } catch (err) {
    hcShowToast(err.message, 'error');
  }
}

const CATEGORY_ICONS = {
  'Fruits': 'bi-apple',
  'Vegetables': 'bi-egg',
  'Dairy & Eggs': 'bi-cup-straw',
  'Bakery': 'bi-basket',
  'Meat & Seafood': 'bi-fish',
  'Beverages': 'bi-cup-hot',
  'Snacks': 'bi-cookie',
  'Pantry Staples': 'bi-box-seam'
};

async function loadHomeCategories() {
  const wrap = document.getElementById('hc-categories');
  try {
    const categories = await Api.get('/categories');
    wrap.innerHTML = categories.map(c => `
      <div class="col">
        <a href="products.html?category=${c.id}" class="hc-category-chip">
          <i class="bi ${CATEGORY_ICONS[c.name] || 'bi-basket'}"></i>
          <div class="small mt-2 fw-semibold">${c.name}</div>
        </a>
      </div>
    `).join('');
  } catch (err) {
    wrap.innerHTML = `<div class="col-12 text-muted small">Could not load categories — is the backend running?</div>`;
  }
}

async function loadFeatured() {
  const wrap = document.getElementById('hc-featured');
  try {
    const data = await Api.get('/products?featured=true&limit=8');
    if (data.products.length === 0) {
      wrap.innerHTML = `<div class="col-12 text-muted small">No featured products yet.</div>`;
      return;
    }
    wrap.innerHTML = data.products.map(productCardHTML).join('');
  } catch (err) {
    wrap.innerHTML = `<div class="col-12 text-muted small">Could not load products — is the backend running on http://localhost:5000?</div>`;
  }
}

document.addEventListener('DOMContentLoaded', () => {
  loadHomeCategories();
  loadFeatured();
});
