async function loadDashboard() {
  if (!Api.isLoggedIn() || !Api.isAdmin()) return;

  try {
    const stats = await Api.get('/admin/stats');

    document.getElementById('stat-orders').textContent = stats.totalOrders;
    document.getElementById('stat-revenue').textContent = `$${Number(stats.totalRevenue).toFixed(2)}`;
    document.getElementById('stat-products').textContent = stats.totalProducts;
    document.getElementById('stat-customers').textContent = stats.totalCustomers;

    const recentWrap = document.getElementById('recent-orders');
    recentWrap.innerHTML = stats.recentOrders.length
      ? `<table class="table table-sm align-middle">
           <thead><tr class="text-muted small text-uppercase"><th>#</th><th>Customer</th><th>Total</th><th>Status</th></tr></thead>
           <tbody>
             ${stats.recentOrders.map(o => `
               <tr>
                 <td>#${o.id}</td>
                 <td class="small">${o.customer_name}</td>
                 <td class="hc-price-tag small">$${Number(o.total_amount).toFixed(2)}</td>
                 <td><span class="hc-status hc-status-${o.status}">${o.status}</span></td>
               </tr>`).join('')}
           </tbody>
         </table>`
      : `<p class="text-muted small">No orders yet.</p>`;

    const lowStockWrap = document.getElementById('low-stock');
    lowStockWrap.innerHTML = stats.lowStock.length
      ? stats.lowStock.map(p => `
          <div class="d-flex justify-content-between align-items-center py-2 border-bottom small">
            <span>${p.name}</span>
            <span class="hc-status ${p.stock === 0 ? 'hc-status-cancelled' : 'hc-status-pending'}">${p.stock} left</span>
          </div>`).join('')
      : `<p class="text-muted small">All products are well stocked.</p>`;
  } catch (err) {
    console.error(err);
  }
}

document.addEventListener('DOMContentLoaded', loadDashboard);
