/**
 * Thin wrapper around fetch() for talking to the Grocery Store REST API.
 * Change API_BASE_URL if your backend runs somewhere other than localhost:5000.
 */
const API_BASE_URL = 'http://localhost:5000/api';

const Api = {
  token() {
    return localStorage.getItem('hc_token');
  },

  setToken(token) {
    localStorage.setItem('hc_token', token);
  },

  clearToken() {
    localStorage.removeItem('hc_token');
    localStorage.removeItem('hc_user');
  },

  currentUser() {
    const raw = localStorage.getItem('hc_user');
    return raw ? JSON.parse(raw) : null;
  },

  setUser(user) {
    localStorage.setItem('hc_user', JSON.stringify(user));
  },

  isLoggedIn() {
    return !!this.token();
  },

  isAdmin() {
    const user = this.currentUser();
    return !!user && user.role === 'admin';
  },

  logout() {
    this.clearToken();
    window.location.href = 'index.html';
  },

  async request(path, options = {}) {
    const headers = { 'Content-Type': 'application/json', ...(options.headers || {}) };
    const token = this.token();
    if (token) headers['Authorization'] = `Bearer ${token}`;

    let response;
    try {
      response = await fetch(`${API_BASE_URL}${path}`, { ...options, headers });
    } catch (err) {
      throw new Error('Could not reach the server. Is the backend running on http://localhost:5000?');
    }

    let data = null;
    try { data = await response.json(); } catch (e) { /* no body */ }

    if (!response.ok) {
      const message = (data && data.message) || `Request failed (${response.status})`;
      throw new Error(message);
    }
    return data;
  },

  get(path) { return this.request(path, { method: 'GET' }); },
  post(path, body) { return this.request(path, { method: 'POST', body: JSON.stringify(body) }); },
  put(path, body) { return this.request(path, { method: 'PUT', body: JSON.stringify(body) }); },
  del(path) { return this.request(path, { method: 'DELETE' }); }
};
