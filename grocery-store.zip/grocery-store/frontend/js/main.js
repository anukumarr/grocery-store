/**
 * Shared behavior loaded on every page: navbar auth state, cart badge count,
 * toast notifications, and a small helper for formatting money.
 */

function hcFormatMoney(amount) {
  return `$${Number(amount).toFixed(2)}`;
}

function hcShowToast(message, type = 'success') {
  let container = document.querySelector('.toast-container');
  if (!container) {
    container = document.createElement('div');
    container.className = 'toast-container position-fixed bottom-0 end-0 p-3';
    document.body.appendChild(container);
  }

  const bg = type === 'error' ? 'bg-danger' : type === 'info' ? 'bg-primary' : 'bg-success';
  const toastEl = document.createElement('div');
  toastEl.className = `toast align-items-center text-white ${bg} border-0`;
  toastEl.setAttribute('role', 'alert');
  toastEl.innerHTML = `
    <div class="d-flex">
      <div class="toast-body">${message}</div>
      <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
    </div>`;
  container.appendChild(toastEl);
  const toast = new bootstrap.Toast(toastEl, { delay: 3000 });
  toast.show();
  toastEl.addEventListener('hidden.bs.toast', () => toastEl.remove());
}

async function hcRefreshCartBadge() {
  const badge = document.getElementById('hc-cart-count');
  if (!badge) return;

  if (!Api.isLoggedIn()) {
    badge.classList.add('d-none');
    return;
  }

  try {
    const cart = await Api.get('/cart');
    const count = cart.items.reduce((sum, i) => sum + i.quantity, 0);
    if (count > 0) {
      badge.textContent = count;
      badge.classList.remove('d-none');
    } else {
      badge.classList.add('d-none');
    }
  } catch (err) {
    badge.classList.add('d-none');
  }
}

function hcUpdateNavForAuth() {
  const user = Api.currentUser();
  const guestLinks = document.getElementById('hc-guest-links');
  const userLinks = document.getElementById('hc-user-links');
  const adminLink = document.getElementById('hc-admin-link');
  const userNameEl = document.getElementById('hc-user-name');

  if (user) {
    if (guestLinks) guestLinks.classList.add('d-none');
    if (userLinks) userLinks.classList.remove('d-none');
    if (userNameEl) userNameEl.textContent = user.name.split(' ')[0];
    if (adminLink) adminLink.classList.toggle('d-none', user.role !== 'admin');
  } else {
    if (guestLinks) guestLinks.classList.remove('d-none');
    if (userLinks) userLinks.classList.add('d-none');
    if (adminLink) adminLink.classList.add('d-none');
  }
}

function hcRequireLogin(redirectMessage) {
  if (!Api.isLoggedIn()) {
    if (redirectMessage) sessionStorage.setItem('hc_redirect_message', redirectMessage);
    window.location.href = `login.html?next=${encodeURIComponent(window.location.pathname.split('/').pop())}`;
    return false;
  }
  return true;
}

function hcHighlightActiveNav() {
  const current = window.location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.hc-navbar .nav-link[data-page]').forEach(link => {
    if (link.dataset.page === current) link.classList.add('active');
  });
}

document.addEventListener('DOMContentLoaded', () => {
  hcUpdateNavForAuth();
  hcRefreshCartBadge();
  hcHighlightActiveNav();

  const logoutBtn = document.getElementById('hc-logout-btn');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', (e) => {
      e.preventDefault();
      Api.logout();
    });
  }

  const redirectMsg = sessionStorage.getItem('hc_redirect_message');
  if (redirectMsg) {
    hcShowToast(redirectMsg, 'info');
    sessionStorage.removeItem('hc_redirect_message');
  }
});
