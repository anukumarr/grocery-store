const DELIVERY_FEE = 4.99;
const FREE_DELIVERY_THRESHOLD = 30;

async function loadCart() {
  const wrap = document.getElementById('hc-cart-items');

  if (!Api.isLoggedIn()) {
    wrap.innerHTML = `
      <div class="hc-empty-state">
        <i class="bi bi-basket3"></i>
        <p class="mt-3">Sign in to see your cart.</p>
        <a href="login.html?next=cart.html" class="btn btn-hc-primary mt-2">Sign In</a>
      </div>`;
    renderSummary({ subtotal: 0 });
    document.getElementById('hc-checkout-btn').disabled = true;
    return;
  }

  try {
    const cart = await Api.get('/cart');
    if (cart.items.length === 0) {
      wrap.innerHTML = `
        <div class="hc-empty-state">
          <i class="bi bi-basket"></i>
          <p class="mt-3">Your cart is empty.</p>
          <a href="products.html" class="btn btn-hc-primary mt-2">Start Shopping</a>
        </div>`;
      document.getElementById('hc-checkout-btn').disabled = true;
    } else {
      wrap.innerHTML = cart.items.map(item => `
        <div class="hc-cart-row" data-item-id="${item.cart_item_id}">
          <img src="${item.image_url || 'https://via.placeholder.com/72'}" alt="${item.name}">
          <div class="flex-grow-1">
            <a href="product-detail.html?id=${item.product_id}" class="hc-product-name">${item.name}</a>
            <div class="hc-product-unit">${hcFormatMoney(item.final_price)} / ${item.unit}</div>
          </div>
          <div class="hc-qty-control">
            <button type="button" onclick="hcUpdateQty(${item.cart_item_id}, ${item.quantity - 1})">-</button>
            <input type="number" value="${item.quantity}" min="1" max="${item.stock}"
                   onchange="hcUpdateQty(${item.cart_item_id}, this.value)">
            <button type="button" onclick="hcUpdateQty(${item.cart_item_id}, ${item.quantity + 1})">+</button>
          </div>
          <div class="hc-price-tag" style="min-width:70px; text-align:right;">${hcFormatMoney(item.final_price * item.quantity)}</div>
          <button class="btn btn-sm text-danger" onclick="hcRemoveItem(${item.cart_item_id})"><i class="bi bi-trash"></i></button>
        </div>
      `).join('');
      document.getElementById('hc-checkout-btn').disabled = false;
    }
    renderSummary(cart);
  } catch (err) {
    wrap.innerHTML = `<div class="text-muted small">Could not load your cart — ${err.message}</div>`;
  }
}

function renderSummary(cart) {
  const subtotal = cart.subtotal || 0;
  const delivery = subtotal === 0 || subtotal >= FREE_DELIVERY_THRESHOLD ? 0 : DELIVERY_FEE;
  const total = subtotal + delivery;

  document.getElementById('hc-subtotal').textContent = hcFormatMoney(subtotal);
  document.getElementById('hc-delivery').textContent = delivery === 0 ? 'FREE' : hcFormatMoney(delivery);
  document.getElementById('hc-total').textContent = hcFormatMoney(total);
}

async function hcUpdateQty(itemId, newQty) {
  newQty = parseInt(newQty);
  if (!newQty || newQty < 1) return;
  try {
    await Api.put(`/cart/${itemId}`, { quantity: newQty });
    loadCart();
    hcRefreshCartBadge();
  } catch (err) {
    hcShowToast(err.message, 'error');
    loadCart();
  }
}

async function hcRemoveItem(itemId) {
  try {
    await Api.del(`/cart/${itemId}`);
    hcShowToast('Item removed');
    loadCart();
    hcRefreshCartBadge();
  } catch (err) {
    hcShowToast(err.message, 'error');
  }
}

document.addEventListener('DOMContentLoaded', () => {
  loadCart();
  document.getElementById('hc-checkout-btn').addEventListener('click', () => {
    window.location.href = 'checkout.html';
  });
});
