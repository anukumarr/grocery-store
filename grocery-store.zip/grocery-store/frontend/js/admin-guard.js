/**
 * Include this on every admin page (after api.js, before the page-specific script).
 * Redirects non-admins away and hooks up the logout button.
 */
(function () {
  if (!Api.isLoggedIn() || !Api.isAdmin()) {
    const guard = document.getElementById('hc-admin-guard');
    const content = document.getElementById('hc-admin-content');
    if (content) content.classList.add('d-none');
    if (guard) {
      guard.innerHTML = `
        <div class="alert alert-warning">
          You must be signed in as an admin to view this page.
          <a href="../login.html">Sign in</a>
        </div>`;
    } else {
      window.location.href = '../login.html';
    }
  }

  document.addEventListener('DOMContentLoaded', () => {
    const logoutBtn = document.getElementById('hc-admin-logout-btn');
    if (logoutBtn) {
      logoutBtn.addEventListener('click', (e) => {
        e.preventDefault();
        Api.clearToken();
        window.location.href = '../index.html';
      });
    }
  });
})();
