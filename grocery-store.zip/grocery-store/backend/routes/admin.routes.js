const express = require('express');
const router = express.Router();
const { getAllOrders, updateOrderStatus, getStats } = require('../controllers/orders.controller');
const { protect, adminOnly } = require('../middleware/auth');

router.use(protect, adminOnly); // everything below requires an admin JWT

router.get('/stats', getStats);
router.get('/orders', getAllOrders);
router.put('/orders/:id/status', updateOrderStatus);

module.exports = router;
