const express = require('express');
const router = express.Router();
const {
  getProducts, getProductById, createProduct, updateProduct, deleteProduct,
  getCategories, createCategory
} = require('../controllers/products.controller');
const { protect, adminOnly } = require('../middleware/auth');

// Public
router.get('/products', getProducts);
router.get('/products/:id', getProductById);
router.get('/categories', getCategories);

// Admin only
router.post('/products', protect, adminOnly, createProduct);
router.put('/products/:id', protect, adminOnly, updateProduct);
router.delete('/products/:id', protect, adminOnly, deleteProduct);
router.post('/categories', protect, adminOnly, createCategory);

module.exports = router;
