/**
 * Run this once after installing dependencies and setting up the database:
 *
 *   node database/createAdmin.js
 *
 * It creates (or resets) the default admin account:
 *   email:    admin@grocerystore.com
 *   password: Admin@123
 *
 * You can change the email/password below before running it, or pass them
 * as CLI args: node database/createAdmin.js myemail@site.com MyPassword1
 */
require('dotenv').config();
const bcrypt = require('bcryptjs');
const pool = require('../config/db');

async function run() {
  const email = process.argv[2] || 'admin@grocerystore.com';
  const password = process.argv[3] || 'Admin@123';
  const name = 'Store Admin';

  try {
    const hashed = await bcrypt.hash(password, 10);

    const [existing] = await pool.query('SELECT id FROM users WHERE email = ?', [email]);

    if (existing.length > 0) {
      await pool.query('UPDATE users SET password = ?, role = "admin" WHERE email = ?', [hashed, email]);
      console.log(`✅ Existing user updated to admin: ${email}`);
    } else {
      await pool.query(
        'INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, "admin")',
        [name, email, hashed]
      );
      console.log(`✅ Admin created: ${email} / ${password}`);
    }
  } catch (err) {
    console.error('❌ Failed to create admin:', err.message);
  } finally {
    await pool.end();
  }
}

run();
