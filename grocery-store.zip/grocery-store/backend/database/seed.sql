USE grocery_store;

-- ---------- Categories ----------
INSERT INTO categories (name, icon) VALUES
('Fruits', 'bi-apple'),
('Vegetables', 'bi-egg'),
('Dairy & Eggs', 'bi-cup-straw'),
('Bakery', 'bi-basket'),
('Meat & Seafood', 'bi-fish'),
('Beverages', 'bi-cup'),
('Snacks', 'bi-cookie'),
('Pantry Staples', 'bi-box-seam');

-- ---------- Products ----------
INSERT INTO products (name, description, price, unit, stock, image_url, category_id, is_featured, is_organic, discount_percent) VALUES
('Fresh Red Apples', 'Crisp, juicy red apples picked at peak ripeness.', 3.49, 'kg', 120, 'https://loremflickr.com/400/300/apple,fruit', 1, 1, 1, 0),
('Bananas', 'Sweet ripe bananas, great for smoothies and snacking.', 1.29, 'kg', 200, 'https://loremflickr.com/400/300/banana,fruit', 1, 1, 0, 0),
('Seedless Grapes', 'Sweet green seedless grapes.', 4.99, 'kg', 80, 'https://loremflickr.com/400/300/grapes,fruit', 1, 0, 0, 10),
('Strawberries', 'Fresh farm strawberries, hand-picked.', 5.49, 'box', 60, 'https://loremflickr.com/400/300/strawberry,fruit', 1, 1, 1, 0),
('Oranges', 'Juicy navel oranges packed with vitamin C.', 2.99, 'kg', 150, 'https://loremflickr.com/400/300/orange,fruit', 1, 0, 0, 0),

('Broccoli', 'Fresh green broccoli crowns.', 2.49, 'kg', 90, 'https://loremflickr.com/400/300/broccoli,vegetable', 2, 0, 1, 0),
('Carrots', 'Sweet crunchy carrots.', 1.79, 'kg', 140, 'https://loremflickr.com/400/300/carrot,vegetable', 2, 1, 0, 0),
('Tomatoes', 'Vine-ripened red tomatoes.', 2.29, 'kg', 130, 'https://loremflickr.com/400/300/tomato,vegetable', 2, 1, 0, 0),
('Spinach', 'Fresh leafy spinach, washed and ready.', 1.99, 'bunch', 75, 'https://loremflickr.com/400/300/spinach,vegetable', 2, 0, 1, 0),
('Potatoes', 'All-purpose potatoes, great for roasting.', 1.49, 'kg', 200, 'https://loremflickr.com/400/300/potato,vegetable', 2, 0, 0, 5),

('Whole Milk', 'Fresh whole milk, 1 gallon.', 3.99, 'gallon', 60, 'https://loremflickr.com/400/300/milk,dairy', 3, 1, 0, 0),
('Farm Eggs (Dozen)', 'Free-range brown eggs.', 4.49, 'dozen', 100, 'https://loremflickr.com/400/300/eggs,carton', 3, 1, 0, 0),
('Cheddar Cheese', 'Aged sharp cheddar block.', 6.99, '250g', 50, 'https://loremflickr.com/400/300/cheese,cheddar', 3, 0, 0, 0),
('Greek Yogurt', 'Creamy plain Greek yogurt.', 4.29, '500g', 70, 'https://loremflickr.com/400/300/yogurt,dairy', 3, 0, 0, 0),
('Butter', 'Salted creamery butter.', 3.29, '250g', 90, 'https://loremflickr.com/400/300/butter,dairy', 3, 0, 0, 0),

('Sourdough Bread', 'Freshly baked sourdough loaf.', 4.99, 'loaf', 40, 'https://loremflickr.com/400/300/sourdough,bread', 4, 1, 0, 0),
('Croissants (4-pack)', 'Buttery, flaky croissants.', 5.49, 'pack', 35, 'https://loremflickr.com/400/300/croissant,bakery', 4, 0, 0, 0),
('Bagels (6-pack)', 'Classic New York style bagels.', 4.49, 'pack', 45, 'https://loremflickr.com/400/300/bagel,bakery', 4, 0, 0, 0),

('Chicken Breast', 'Boneless skinless chicken breast.', 8.99, 'kg', 55, 'https://loremflickr.com/400/300/chicken,meat', 5, 1, 0, 0),
('Salmon Fillet', 'Fresh Atlantic salmon fillet.', 14.99, 'kg', 30, 'https://loremflickr.com/400/300/salmon,seafood', 5, 1, 0, 0),
('Ground Beef', 'Lean ground beef, 90/10.', 9.49, 'kg', 45, 'https://loremflickr.com/400/300/beef,meat', 5, 0, 0, 0),
('Shrimp', 'Peeled and deveined jumbo shrimp.', 12.99, 'kg', 25, 'https://loremflickr.com/400/300/shrimp,seafood', 5, 0, 0, 15),

('Orange Juice', '100% pure squeezed orange juice.', 3.99, '1L', 80, 'https://loremflickr.com/400/300/orangejuice,drink', 6, 0, 0, 0),
('Sparkling Water', 'Naturally carbonated spring water.', 1.49, '1L', 120, 'https://loremflickr.com/400/300/sparklingwater,drink', 6, 0, 0, 0),
('Ground Coffee', 'Medium roast ground coffee.', 7.99, '250g', 60, 'https://loremflickr.com/400/300/coffee,beans', 6, 1, 0, 0),
('Green Tea', 'Organic loose leaf green tea.', 5.49, '100g', 50, 'https://loremflickr.com/400/300/greentea,tea', 6, 0, 1, 0),

('Potato Chips', 'Crispy sea salt potato chips.', 2.99, '150g', 100, 'https://loremflickr.com/400/300/chips,snack', 7, 0, 0, 0),
('Mixed Nuts', 'Roasted and salted mixed nuts.', 6.49, '300g', 65, 'https://loremflickr.com/400/300/nuts,snack', 7, 0, 0, 0),
('Dark Chocolate Bar', '70% cocoa dark chocolate.', 3.49, '100g', 90, 'https://loremflickr.com/400/300/chocolate,bar', 7, 1, 0, 0),

('Basmati Rice', 'Premium long-grain basmati rice.', 8.99, '5kg', 70, 'https://loremflickr.com/400/300/rice,bag', 8, 0, 0, 0),
('Olive Oil', 'Extra virgin cold-pressed olive oil.', 9.99, '500ml', 55, 'https://loremflickr.com/400/300/oliveoil,bottle', 8, 1, 1, 0),
('Pasta', 'Durum wheat spaghetti pasta.', 1.99, '500g', 110, 'https://loremflickr.com/400/300/pasta,spaghetti', 8, 0, 0, 0),
('Sea Salt', 'Fine ground natural sea salt.', 1.49, '400g', 100, 'https://loremflickr.com/400/300/salt,kitchen', 8, 0, 0, 0);
