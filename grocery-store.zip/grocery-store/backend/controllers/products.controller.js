const pool = require('../config/db');

// GET /api/products?search=&category=&sort=&page=&limit=
exports.getProducts = async (req, res) => {
  try {
    const { search, category, sort, page = 1, limit = 12, featured } = req.query;
    const offset = (Math.max(1, parseInt(page)) - 1) * parseInt(limit);

    let where = 'WHERE 1=1';
    const params = [];

    if (search) {
      where += ' AND (p.name LIKE ? OR p.description LIKE ?)';
      params.push(`%${search}%`, `%${search}%`);
    }
    if (category) {
      where += ' AND p.category_id = ?';
      params.push(category);
    }
    if (featured === 'true') {
      where += ' AND p.is_featured = 1';
    }

    let orderBy = 'p.created_at DESC';
    if (sort === 'price_asc') orderBy = 'p.price ASC';
    if (sort === 'price_desc') orderBy = 'p.price DESC';
    if (sort === 'name_asc') orderBy = 'p.name ASC';

    const [rows] = await pool.query(
      `SELECT p.*, c.name AS category_name
       FROM products p
       LEFT JOIN categories c ON p.category_id = c.id
       ${where}
       ORDER BY ${orderBy}
       LIMIT ? OFFSET ?`,
      [...params, parseInt(limit), offset]
    );

    const [countRows] = await pool.query(
      `SELECT COUNT(*) AS total FROM products p ${where}`,
      params
    );

    res.json({
      products: rows,
      total: countRows[0].total,
      page: parseInt(page),
      totalPages: Math.ceil(countRows[0].total / limit)
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error fetching products' });
  }
};

// GET /api/products/:id
exports.getProductById = async (req, res) => {
  try {
    const [rows] = await pool.query(
      `SELECT p.*, c.name AS category_name
       FROM products p LEFT JOIN categories c ON p.category_id = c.id
       WHERE p.id = ?`,
      [req.params.id]
    );
    if (rows.length === 0) return res.status(404).json({ message: 'Product not found' });
    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error fetching product' });
  }
};

// POST /api/products (admin)
exports.createProduct = async (req, res) => {
  try {
    const {
      name, description, price, unit, stock,
      image_url, category_id, is_featured, is_organic, discount_percent
    } = req.body;

    if (!name || price === undefined) {
      return res.status(400).json({ message: 'Name and price are required' });
    }

    const [result] = await pool.query(
      `INSERT INTO products
       (name, description, price, unit, stock, image_url, category_id, is_featured, is_organic, discount_percent)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        name, description || '', price, unit || 'each', stock || 0,
        image_url || null, category_id || null,
        is_featured ? 1 : 0, is_organic ? 1 : 0, discount_percent || 0
      ]
    );

    res.status(201).json({ id: result.insertId, message: 'Product created successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error creating product' });
  }
};

// PUT /api/products/:id (admin)
exports.updateProduct = async (req, res) => {
  try {
    const {
      name, description, price, unit, stock,
      image_url, category_id, is_featured, is_organic, discount_percent
    } = req.body;

    const [existing] = await pool.query('SELECT id FROM products WHERE id = ?', [req.params.id]);
    if (existing.length === 0) return res.status(404).json({ message: 'Product not found' });

    await pool.query(
      `UPDATE products SET
        name = ?, description = ?, price = ?, unit = ?, stock = ?,
        image_url = ?, category_id = ?, is_featured = ?, is_organic = ?, discount_percent = ?
       WHERE id = ?`,
      [
        name, description, price, unit, stock,
        image_url, category_id || null, is_featured ? 1 : 0, is_organic ? 1 : 0,
        discount_percent || 0, req.params.id
      ]
    );

    res.json({ message: 'Product updated successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error updating product' });
  }
};

// DELETE /api/products/:id (admin)
exports.deleteProduct = async (req, res) => {
  try {
    const [result] = await pool.query('DELETE FROM products WHERE id = ?', [req.params.id]);
    if (result.affectedRows === 0) return res.status(404).json({ message: 'Product not found' });
    res.json({ message: 'Product deleted successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error deleting product' });
  }
};

// GET /api/categories
exports.getCategories = async (req, res) => {
  try {
    const [rows] = await pool.query('SELECT * FROM categories ORDER BY name ASC');
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error fetching categories' });
  }
};

// POST /api/categories (admin)
exports.createCategory = async (req, res) => {
  try {
    const { name, icon } = req.body;
    if (!name) return res.status(400).json({ message: 'Category name is required' });

    const [result] = await pool.query(
      'INSERT INTO categories (name, icon) VALUES (?, ?)',
      [name, icon || null]
    );
    res.status(201).json({ id: result.insertId, message: 'Category created successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error creating category' });
  }
};
