const pool = require('../config/db');

// Very small mock payment gateway simulator.
// In a real app this would call Stripe/Razorpay/etc. Here we just validate
// basic card shape and simulate a network round-trip.
function processMockPayment({ payment_method, card_number, card_expiry, card_cvv }) {
  if (payment_method === 'cod') {
    return { success: true, status: 'pending' }; // paid on delivery
  }

  // card or upi - do a light validation so obviously-fake input fails
  if (payment_method === 'card') {
    const digitsOnly = (card_number || '').replace(/\s/g, '');
    if (digitsOnly.length < 12 || !/^\d+$/.test(digitsOnly)) {
      return { success: false, message: 'Invalid card number' };
    }
    if (!card_expiry || !card_cvv || card_cvv.length < 3) {
      return { success: false, message: 'Invalid card expiry or CVV' };
    }
  }

  // Simulate a successful charge
  return { success: true, status: 'paid' };
}

// POST /api/orders  - checkout: creates order from current cart
exports.createOrder = async (req, res) => {
  const connection = await pool.getConnection();
  try {
    const {
      shipping_name, shipping_phone, shipping_address, shipping_city, shipping_zip,
      payment_method = 'cod', card_number, card_expiry, card_cvv
    } = req.body;

    if (!shipping_name || !shipping_phone || !shipping_address || !shipping_city || !shipping_zip) {
      return res.status(400).json({ message: 'Complete shipping details are required' });
    }

    await connection.beginTransaction();

    const [cartRows] = await connection.query(
      `SELECT ci.quantity, p.id AS product_id, p.name, p.price, p.stock, p.discount_percent
       FROM cart_items ci JOIN products p ON ci.product_id = p.id
       WHERE ci.user_id = ?`,
      [req.user.id]
    );

    if (cartRows.length === 0) {
      await connection.rollback();
      return res.status(400).json({ message: 'Your cart is empty' });
    }

    // Check stock availability
    for (const item of cartRows) {
      if (item.quantity > item.stock) {
        await connection.rollback();
        return res.status(409).json({ message: `Not enough stock for "${item.name}" (only ${item.stock} left)` });
      }
    }

    const total = cartRows.reduce((sum, item) => {
      const finalPrice = item.price - (item.price * (item.discount_percent || 0)) / 100;
      return sum + finalPrice * item.quantity;
    }, 0);

    // Run mock payment
    const payment = processMockPayment({ payment_method, card_number, card_expiry, card_cvv });
    if (!payment.success) {
      await connection.rollback();
      return res.status(402).json({ message: payment.message || 'Payment failed' });
    }

    const [orderResult] = await connection.query(
      `INSERT INTO orders
       (user_id, total_amount, status, payment_method, payment_status,
        shipping_name, shipping_phone, shipping_address, shipping_city, shipping_zip)
       VALUES (?, ?, 'pending', ?, ?, ?, ?, ?, ?, ?)`,
      [
        req.user.id, total.toFixed(2), payment_method, payment.status,
        shipping_name, shipping_phone, shipping_address, shipping_city, shipping_zip
      ]
    );
    const orderId = orderResult.insertId;

    for (const item of cartRows) {
      const finalPrice = item.price - (item.price * (item.discount_percent || 0)) / 100;
      await connection.query(
        `INSERT INTO order_items (order_id, product_id, product_name, price, quantity)
         VALUES (?, ?, ?, ?, ?)`,
        [orderId, item.product_id, item.name, finalPrice.toFixed(2), item.quantity]
      );
      await connection.query(
        `UPDATE products SET stock = stock - ? WHERE id = ?`,
        [item.quantity, item.product_id]
      );
    }

    await connection.query('DELETE FROM cart_items WHERE user_id = ?', [req.user.id]);

    await connection.commit();

    res.status(201).json({
      message: 'Order placed successfully',
      order_id: orderId,
      total_amount: Number(total.toFixed(2)),
      payment_status: payment.status
    });
  } catch (err) {
    await connection.rollback();
    console.error(err);
    res.status(500).json({ message: 'Server error placing order' });
  } finally {
    connection.release();
  }
};

// GET /api/orders - current user's order history
exports.getMyOrders = async (req, res) => {
  try {
    const [orders] = await pool.query(
      'SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC',
      [req.user.id]
    );
    res.json(orders);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error fetching orders' });
  }
};

// GET /api/orders/:id - order detail (owner or admin)
exports.getOrderById = async (req, res) => {
  try {
    const [orders] = await pool.query('SELECT * FROM orders WHERE id = ?', [req.params.id]);
    if (orders.length === 0) return res.status(404).json({ message: 'Order not found' });

    const order = orders[0];
    if (order.user_id !== req.user.id && req.user.role !== 'admin') {
      return res.status(403).json({ message: 'Not authorized to view this order' });
    }

    const [items] = await pool.query('SELECT * FROM order_items WHERE order_id = ?', [req.params.id]);
    res.json({ ...order, items });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error fetching order' });
  }
};

// ---------- Admin ----------

// GET /api/admin/orders - all orders
exports.getAllOrders = async (req, res) => {
  try {
    const [orders] = await pool.query(
      `SELECT o.*, u.name AS customer_name, u.email AS customer_email
       FROM orders o JOIN users u ON o.user_id = u.id
       ORDER BY o.created_at DESC`
    );
    res.json(orders);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error fetching orders' });
  }
};

// PUT /api/admin/orders/:id/status  { status }
exports.updateOrderStatus = async (req, res) => {
  try {
    const { status } = req.body;
    const valid = ['pending', 'processing', 'shipped', 'delivered', 'cancelled'];
    if (!valid.includes(status)) {
      return res.status(400).json({ message: 'Invalid status value' });
    }

    const [result] = await pool.query('UPDATE orders SET status = ? WHERE id = ?', [status, req.params.id]);
    if (result.affectedRows === 0) return res.status(404).json({ message: 'Order not found' });

    res.json({ message: 'Order status updated' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error updating order status' });
  }
};

// GET /api/admin/stats - dashboard summary
exports.getStats = async (req, res) => {
  try {
    const [[{ totalOrders }]] = await pool.query('SELECT COUNT(*) AS totalOrders FROM orders');
    const [[{ totalRevenue }]] = await pool.query(
      `SELECT COALESCE(SUM(total_amount),0) AS totalRevenue FROM orders WHERE payment_status = 'paid' OR payment_method = 'cod'`
    );
    const [[{ totalProducts }]] = await pool.query('SELECT COUNT(*) AS totalProducts FROM products');
    const [[{ totalCustomers }]] = await pool.query(`SELECT COUNT(*) AS totalCustomers FROM users WHERE role = 'customer'`);
    const [lowStock] = await pool.query('SELECT id, name, stock FROM products WHERE stock <= 10 ORDER BY stock ASC LIMIT 5');
    const [recentOrders] = await pool.query(
      `SELECT o.id, o.total_amount, o.status, o.created_at, u.name AS customer_name
       FROM orders o JOIN users u ON o.user_id = u.id ORDER BY o.created_at DESC LIMIT 5`
    );

    res.json({ totalOrders, totalRevenue, totalProducts, totalCustomers, lowStock, recentOrders });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error fetching stats' });
  }
};
